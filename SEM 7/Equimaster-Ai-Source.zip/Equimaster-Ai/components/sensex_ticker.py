"""
Continuous scrolling BSE Sensex 30 stock ticker for Streamlit.
Fetches live data from Yahoo Finance via yfinance.
"""

import streamlit as st
import streamlit.components.v1 as components
import logging
import sys
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from config import SENSEX_30_TICKERS

logger = logging.getLogger(__name__)


def _fetch_single_sensex_stock(ticker_item):
    """Fetch data for a single Sensex stock."""
    ticker_sym, company_name = ticker_item
    try:
        import yfinance as yf
        ticker = yf.Ticker(ticker_sym)
        info = ticker.info

        # Get current price and previous close
        current_price = info.get('regularMarketPrice') or info.get('currentPrice') or info.get('lastPrice')
        prev_close = info.get('regularMarketPreviousClose') or info.get('previousClose')

        if current_price and prev_close:
            change_pct = ((current_price - prev_close) / prev_close) * 100
            return {
                "symbol": ticker_sym.replace('.NS', ''),
                "name": company_name,
                "price": current_price,
                "change_pct": change_pct
            }
    except Exception as exc:
        logger.warning("Sensex quote fetch failed for %s (%s)", ticker_sym, type(exc).__name__)
    return None

# Cache with minimal TTL for near real-time data
@st.cache_data(ttl=30)
def fetch_sensex_data():
    """
    Fetch live data for all 30 Sensex stocks from Yahoo Finance in parallel.
    Returns list of dicts with symbol, name, price, change_pct, or None
    when live quotes are unavailable.
    """
    try:
        import yfinance as yf
    except ImportError:
        logger.error("Sensex quotes unavailable because yfinance is not installed")
        return None

    # All 30 Sensex constituents with Yahoo Finance ticker symbols (.NS for NSE)
    sensex_tickers = SENSEX_30_TICKERS

    live_data = []
    
    # Parallel fetch using ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(_fetch_single_sensex_stock, item): item for item in sensex_tickers.items()}
        for future in as_completed(futures):
            result = future.result()
            if result:
                live_data.append(result)

    return live_data if live_data else None


def render_sensex_ticker():
    """
    Renders a smooth, horizontally scrolling ticker for all 30 BSE Sensex companies.
    Uses CSS animation for continuous marquee effect. Pauses on hover.
    Fetches live data from yfinance with 30s cache.
    """

    # Fetch live data (30s cache for minimal delay)
    live_data = fetch_sensex_data()

    if live_data is None:
        st.caption("Sensex quotes are temporarily unavailable.")
        return
    sensex_stocks = live_data

    # Build ticker items HTML using Python for-loop and f-strings
    ticker_items = []
    for stock in sensex_stocks:
        color_class = "positive" if stock["change_pct"] >= 0 else "negative"
        arrow = "▲" if stock["change_pct"] >= 0 else "▼"

        ticker_items.append(f"""
            <div class="ticker-item">
                <span class="stock-symbol">{stock['symbol']}</span>
                <span class="stock-price">₹{stock['price']:,.2f}</span>
                <span class="stock-change {color_class}">
                    {arrow} {abs(stock['change_pct']):.2f}%
                </span>
            </div>
        """)

    # Duplicate items for seamless infinite scroll
    all_items = ticker_items + ticker_items

    # Generate complete HTML/CSS - Bigger size, consistent fonts
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }}

            .ticker-container {{
                width: 100%;
                height: 65px;
                background: transparent;
                overflow: hidden;
                position: relative;
                border-top: 1px solid rgba(128, 128, 128, 0.2);
                border-bottom: 1px solid rgba(128, 128, 128, 0.2);
            }}

            .ticker-track {{
                display: flex;
                width: max-content;
                height: 100%;
                align-items: center;
                animation: marquee 45s linear infinite;
            }}

            .ticker-container:hover .ticker-track {{
                animation-play-state: paused;
            }}

            @keyframes marquee {{
                0% {{ transform: translateX(0); }}
                100% {{ transform: translateX(-50%); }}
            }}

            .ticker-item {{
                display: inline-flex;
                align-items: center;
                gap: 12px;
                padding: 0 45px;
                white-space: nowrap;
                border-right: 1px solid rgba(128, 128, 128, 0.15);
            }}

            .stock-symbol {{
                font-family: 'Inter', sans-serif;
                font-size: 16px;
                font-weight: 700;
                color: #00C9FF;
                letter-spacing: 0.5px;
                text-transform: uppercase;
            }}

            .stock-price {{
                font-family: 'Inter', sans-serif;
                font-size: 17px;
                font-weight: 600;
                color: #FFFFFF;
            }}

            .stock-change {{
                font-family: 'Inter', sans-serif;
                font-size: 14px;
                font-weight: 600;
                padding: 4px 10px;
                border-radius: 6px;
            }}

            .positive {{
                color: #00D47E;
                background: rgba(0, 212, 126, 0.15);
            }}

            .negative {{
                color: #FF4757;
                background: rgba(255, 71, 87, 0.15);
            }}
        </style>
    </head>
    <body>
        <div class="ticker-container">
            <div class="ticker-track">
                {''.join(all_items)}
            </div>
        </div>
    </body>
    </html>
    """

    components.html(html, height=65)
